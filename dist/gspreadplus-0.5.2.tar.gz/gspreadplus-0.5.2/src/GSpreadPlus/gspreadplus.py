"""
GSpreadPlus: A GSpread Wrapper of a Google Sheets API Wrapper
Description:
This module provides a high-level interface for interacting with Google Sheets as a database
Author: Joel Khor
License: MIT License
"""

from __future__ import annotations
from typing import Optional, Callable, Any, Literal
from functools import wraps

import gspread

from .errors import IdentificationError, SetupError
from .types import SheetOrientation

__all__ = (
    'Spreadclient',
)

def requirements_exists(*requirements):
    """Decorator to check if object has requirements"""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            nonlocal requirements
            if requirements[0] == '*':
                requirements = ['client','document','sheet']
            if args[0].client is None and 'client' in requirements:
                raise SetupError("Client has not been initialised")
            if args[0].document is None and 'document' in requirements:
                raise SetupError("Document has not been connected")
            if args[0].sheet is None and 'sheet' in requirements:
                raise SetupError("Sheet within document has not been connected")
            return func(*args,**kwargs)
        return wrapper
    return decorator

class Spreadclient:
    """The base GSpreadPlus Client to interact with Google Sheets"""
    def __init__(self, credentials: str | dict[str,str]):
        if isinstance(credentials,str):     # Name of Credentials File (.json)
            self.client = gspread.service_account(filename = credentials)
        elif isinstance(credentials,dict):  # Dictionary of Credentials
            self.client = gspread.service_account_from_dict(credentials)
        else:
            self.client = None
            raise SetupError(f"Invalid Credentials of type '{type(credentials)}'")

        self.document: Optional[gspread.models.Spreadsheet] = None
        self.sheet: Optional[gspread.models.Worksheet] = None
        self.listed: Optional[list[list[Any]]] = None
        self.verlisted: Optional[list[list[Any]]] = None
        self.blocklisted: Optional[dict[str, [list[list[Any]]]]] = None
        self.commits: list[gspread.models.Cell] = []
        self.orientation: SheetOrientation = 'vertical'
        self.header_depth: int = 0
        self.block_id_depth: int = 0
        self.block_width: int = 0


    @requirements_exists('client')
    def connect_document(self, identifier):
        """Connect to a Google Sheets Document by key, name or url"""
        methods = [self.client.open_by_key,self.client.open,self.client.open_by_url]
        for method in methods:
            self.document = method(identifier)
            if self.document is not None:
                break
        else:
            raise IdentificationError(
                f"Document identifier <{identifier}> did not fit one of the formats (key,name,url)"
            )

        self.listed = None
        self.verlisted = None
        self.blocklisted = None
        self.sheet = None
        self.commits = []
        self.orientation = 'vertical'
        self.header_depth = 0
        self.block_width = 0

    @requirements_exists('client','document')
    def connect_sheet(
        self, identifier: str="Sheet1",
        orientation: str='vertical',
        header_depth: int=1,
        block_id_depth: int=1,
        block_width: int=0
    ) -> None:
        """Connect to sheet within the connected document by name or index"""
        if isinstance(identifier,str):
            self.sheet = self.document.worksheet(identifier)
            identifier = f"Name '{identifier}'"
        elif isinstance(identifier,int):
            self.sheet = self.document.get_worksheet(identifier)
            identifier = f"Index < {identifier} >"

        self.orientation = orientation
        assert self.orientation in ['vertical','horizontal'], (
            f"orientation <{self.orientation}> not supported, either 'vertical' or 'horizontal'"
        )

        self.header_depth = header_depth
        assert isinstance(self.header_depth,int) and self.header_depth>0, (
            f"header_depth <{self.header_depth}> must be a positive integer"
        )

        self.block_id_depth = block_id_depth
        assert isinstance(self.block_id_depth,int) and self.block_id_depth>0, (
            f"block_id_depth <{self.block_id_depth}> must be a positive integer"
        )

        self.block_width = block_width
        assert isinstance(self.block_width,int) and self.block_width>=0, (
            f"block_width <{self.block_width}> must be a positive integer or 0 to disable"
        )

        if self.sheet is None:
            raise IdentificationError(f"Sheet with the {identifier} Not Found")
        else:
            # Intialize listed on sheet connection
            self.refresh_sheet()

    @requirements_exists('*')
    def refresh_sheet(self):
        """Update local cache of changes and fetch latest data from sheet"""
        if len(self.commits) > 0:
            self.sheet.update_cells(self.commits)
            self.commits = []
        self.listed = self.sheet.get_all_values()
        self.verlisted = list(map(list, zip(*self.listed)))

    @requirements_exists('*')
    def get_row_by_column(
        self, value: str | int, column: str | int=0, refresh: bool=False
    ) -> list[Any]:
        """Get the first row that matches the value in the specified column"""
        if refresh:
            self.refresh_sheet()
        # Pythonic Indexing
        if isinstance(column, str) and column.isalpha():
            index = gspread.utils.a1_to_rowcol(f"{column.upper()}1")[0] - 1
        elif isinstance(column, int):
            index = column
        else:
            raise TypeError(f"Invalid Column identifier of type '{type(column)}'")
        for row in self.listed:
            if row[index] == value:
                return row
        return None

    @requirements_exists('*')
    def get_rows_by_func(self, function: Callable, refresh: bool=False) -> list[Any]:
        """Get all rows that match the condition specified in the function"""
        if refresh:
            self.refresh_sheet()
        match = []
        for row in self.listed:
            if function(row):
                match.append(row)
        return match

    @requirements_exists('*')
    def get_column_by_row(
        self, value: str | int, row: int=0, refresh: bool=False
    ) -> list[Any]:
        """Get the first column that matches the value in the specified row"""
        if refresh:
            self.refresh_sheet()
        # Pythonic Indexing
        if not isinstance(row, int):
            raise TypeError(f"Invalid row identifier of type '{type(row)}'")
        if value in self.listed[row]:
            return [_row[self.listed[row].index(value)] for _row in self.listed]
        return None

    @requirements_exists('*')
    def get_dime_by_header(
        self, value: str | int, header: str | int, refresh: bool=False
    ) -> Optional[list[Any]]:
        """Get the first row/column that matches the value in the specified header"""
        if refresh:
            self.refresh_sheet()
        index = self.get_header_index(header)
        if self.orientation == "vertical":
            for row in self.listed:
                if row[index] == value:
                    return row
            return None
        elif self.orientation == "horizontal":
            if value in self.listed[row]:
                return [_row[self.listed[row].index(value)] for _row in self.listed]
            return None

    @requirements_exists('*')
    def get_block_by_id(self, identifier: str | int, refresh: bool=False) -> list[list[Any]]:
        """Get a block of data by its identifier"""
        if refresh:
            self.refresh_sheet()
        if self.block_width == 0:
            raise SetupError("Block Width is not set, cannot get block by ID")
        if isinstance(identifier, str):
            block_ids = self.block_ids
            if identifier in block_ids:
                start_index = block_ids.index(identifier)
            else:
                raise IdentificationError(
                    f"Block Identifier with name '{identifier}', depth '{self.block_id_depth}' in "
                    f"{self.orientation} orientation not found\nblock_ids starting with: "
                    f"[{', '.join(block_ids[:6])}..."
                )
        elif isinstance(identifier, int):
            start_index = identifier
        else:
            raise TypeError(f"Invalid Block Identifier of type '{type(identifier)}'")
        end_index = start_index + self.block_width
        block = []
        if self.orientation == 'vertical':
            block = [self.verlisted[i][start_index:end_index] for i in range(len(self.verlisted))]
        elif self.orientation == 'horizontal':
            block = [row[start_index:end_index] for row in self.listed]
        return block

    @requirements_exists('*')
    def get_header_index(self, header: str | int, refresh: bool = False) -> int:
        """Get the index of the specified header"""
        if refresh:
            self.refresh_sheet()
        if header in self.headers:
            index = self.headers.index(header)
        else:
            raise IdentificationError(
                f"Header with name '{header}', depth '{self.header_depth}' in {self.orientation} "
                f"orientation not found\nHeaders starting with: [{self.headers[0]},..."
            )
        return index # Pythonic Indexing

    @requirements_exists('*')
    def commit_new_row(
        self, values: list | tuple | dict, offset: int=0, refresh: bool=True
    ) -> list[gspread.cell.Cell]:
        """
        Parameters:
        - values
            Either a list, tuple or dictonary
            A list would be updated in the given order
            A dict would be updated based on the header of the column that corresponds with each key
        - offset
            The number of columns to skip from the left before placing the data
            For by headers method(dict), these columns will not be checked
        - refresh
            The nature of this method defaults this parameter to True
        """
        if refresh:
            self.refresh_sheet()
        new_row_no = len(self.listed)
        old_commits = set(self.commits.copy())
        if isinstance(values,(list, tuple)):
            for k,v in enumerate(values):
                self.commits.append(gspread.cell.Cell(row=new_row_no+1,col=k+1+offset,value=v))
        elif isinstance(values,dict):
            headers = self.headers
            assert headers[offset:]!=[], f'Headers Row Empty (offset={offset})'
            for k,v in values.items():
                if k in headers[offset:]:
                    self.commits.append(
                        gspread.cell.Cell(row=new_row_no+1,col=headers[offset:].index(k)+1,value=v)
                    )
                else:
                    print(f"Dict key <{k}> could not be found in headers...skipping...")
        return [x for x in [
            i for i in self.commits if self.commits.count(x)>1
        ] if x not in old_commits]

    @requirements_exists('*')
    def commit_new_multiple_rows(
        self, values: list[list], offset: int=0, refresh: bool=True
    ) -> list[gspread.cell.Cell]:
        """
        Adds multiple rows to the spreadsheet in a single batch operation.

        Args:
            values: A list of lists, tuples, or dictionaries to be inserted. 
                If a dict is provided, columns are matched by header names.
            offset: The number of columns to skip from the left before placing data.
            refresh: Whether to refresh the local cache after the update. 
                Defaults to True.

        Returns:
            A list of Cell objects representing the updated area.

        Raises:
            IdentificationError: If a header key in a dict cannot be found.
        """
        if refresh:
            self.refresh_sheet()
        new_row_no = len(self.listed)
        old_commits = set(self.commits.copy())
        internal_offset = 0
        if isinstance(values[0],(list, tuple)):
            for item in values:
                for k,v in enumerate(item):
                    self.commits.append(
                        gspread.cell.Cell(row=new_row_no+internal_offset+1,col=k+1+offset,value=v)
                    )
                internal_offset += 1
        elif isinstance(values[0],dict):
            headers = self.headers
            assert headers[offset:]!=[], f'Headers Row Empty (offset={offset})'
            for item in values:
                for k,v in item.items():
                    if k in headers[offset:]:
                        self.commits.append(gspread.cell.Cell(
                            row=new_row_no+internal_offset+1,
                            col=headers[offset:].index(k)+1,
                            value=v
                        ))
                    else:
                        print(f"Dict key <{k}> could not be found in headers...skipping...")
                internal_offset += 1
        if refresh:
            self.refresh_sheet()
        relevant_commits = [i for i in self.commits if self.commits.count(i)>1]
        return [x for x in relevant_commits if x not in old_commits]

    @requirements_exists('*')
    def commit_new_column(
        self, values: list | tuple | dict, offset: int=0, refresh: bool=True
    ) -> list[gspread.cell.Cell]:
        """
        Parameters:
        - values
            Either a list, tuple or dictonary
            A list would be updated in the given order
            A dict would be updated based on the header of the column that corresponds with each key
        - offset
            The number of columns to skip from the left before placing the data
            For by headers method(dict), these columns will not be checked
        - refresh
            The nature of this method defaults this parameter to True
        """
        if refresh:
            self.refresh_sheet()
        new_col_no = len(self.listed[0])
        old_commits = set(self.commits.copy())
        if isinstance(values,(list, tuple)):
            for k,v in enumerate(values):
                self.commits.append(
                    gspread.cell.Cell(row=k+1+offset,col=new_col_no+1,value=v)
                )
        elif isinstance(values,dict):
            headers = self.headers
            assert headers[offset:]!=[], f'Headers Column Empty (offset={offset})'
            for k,v in values.items():
                if k in headers[offset:]:
                    self.commits.append(
                        gspread.cell.Cell(row=headers[offset:].index(k)+1,col=new_col_no+1,value=v)
                    )
                else:
                    print(f"Dict key <{k}> could not be found in headers...skipping...")
        return [x for x in set(self.commits) if x not in old_commits]

    @requirements_exists('*')
    def update_horizontal_entry(self, data: dict[str,Any], primary_key: str, refresh: bool=False):
        """Updates a row (in a vertical data) based on the primary key provided"""
        assert isinstance(data,dict), f"data should be type <'dict'> not {type(data)}"
        active_row = self.get_row_by_column(
            data[primary_key], self.get_header_index(primary_key,refresh=refresh), refresh=refresh
        )
        if active_row is None:
            raise IdentificationError(f'Primary Key ({primary_key}) could not be identified/found')
        active_row_index = self.listed.index(active_row) # Pythonic
        for k,v in data.items():
            if k in self.headers and active_row[self.get_header_index(k,refresh=refresh)]!=v:
                self.commits.append(gspread.cell.Cell(
                    col=self.get_header_index(k,refresh=refresh)+1,row=active_row_index+1,value=v
                ))

    def convert_notation(self, value: str | tuple | list):
        """Util to convert between A1 Notation and [row,col] Notation"""
        if isinstance(value, str):
            return gspread.utils.a1_to_rowcol(value)
        elif isinstance(value, list) or isinstance(value, tuple):
            return gspread.utils.rowcol_to_a1(value[0],value[1])
        else:
            raise TypeError(f"Invalid Input <{value}> not A1 Notation or [row,col]")

    @requirements_exists('*')
    def delete_rows(self, rows: int | list[int] | tuple[int,int]) -> None:
        """Delete (not clear) a row(s) from the sheet"""
        # Row uses Pythonic Indexing
        if isinstance(rows, int):
            rows += 1
            self.sheet.delete_rows(rows)
        elif isinstance(rows,(list,tuple)):
            self.sheet.delete_rows(*rows)
        self.listed = self.sheet.get_all_values()

    @requirements_exists('*')
    def delete_columns(self, cols: int | list[int] | tuple[int,int]) -> None:
        """Delete (not clear) a column from the sheet"""
        # Col uses Pythonic Indexing
        if isinstance(cols, int):
            cols += 1
            self.sheet.delete_columns(cols)
        elif isinstance(cols,(list,tuple)):
            self.sheet.delete_columns(*cols)
        self.listed = self.sheet.get_all_values()

    @property
    @requirements_exists('*')
    def headers(self):
        """Get the headers considering orientation and header depth"""
        if self.listed is not None:
            if getattr(self, 'orientation') == 'vertical':
                return self.listed[self.header_depth-1]
            elif getattr(self, 'orientation') == 'horizontal':
                return [i[self.header_depth-1] for i in self.listed]
            else:
                return []

    @property
    @requirements_exists('*')
    def block_ids(self):
        """Get the block_ids considering orientation and block_id_depth"""
        if self.listed is not None:
            if getattr(self, 'orientation') == 'vertical':
                return [i[self.block_id_depth-1] for i in self.listed]
            elif getattr(self, 'orientation') == 'horizontal':
                return self.listed[self.block_id_depth-1]
            else:
                return []
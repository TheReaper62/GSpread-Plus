'''GSpreadPlus Type Definitions'''
from __future__ import annotations
from typing import Literal

SheetOrientation = Literal['vertical','horizontal']

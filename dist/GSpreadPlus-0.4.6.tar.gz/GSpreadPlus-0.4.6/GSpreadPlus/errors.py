class IdentificationError(Exception):
    pass
